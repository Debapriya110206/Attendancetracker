import { AttendanceRecord } from '../types';

// Generate 3 months of random attendance data for all students across all subjects
const generateAttendanceData = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const today = new Date();
  let recordId = 1;

  // Generate data for past 3 months
  for (let i = 90; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    // Skip weekends
    if (date.getDay() === 0 || date.getDay() === 6) continue;

    // For each student (1-20)
    for (let studentId = 1; studentId <= 20; studentId++) {
      // For each subject (1-5)
      for (let subjectId = 1; subjectId <= 5; subjectId++) {
        // Randomly determine if present (with 85% chance of being present)
        const present = Math.random() > 0.15;
        
        records.push({
          id: recordId++,
          studentId,
          subjectId,
          date: date.toISOString().split('T')[0],
          present
        });
      }
    }
  }

  return records;
};

export const attendanceRecords = generateAttendanceData();

// Functions to calculate and analyze attendance
export const getStudentAttendance = (studentId: number) => {
  const studentRecords = attendanceRecords.filter(
    record => record.studentId === studentId
  );
  
  const totalClasses = studentRecords.length;
  const attendedClasses = studentRecords.filter(record => record.present).length;
  
  return {
    total: totalClasses,
    attended: attendedClasses,
    percentage: totalClasses > 0 ? (attendedClasses / totalClasses) * 100 : 0
  };
};

export const getSubjectAttendance = (studentId: number, subjectId: number) => {
  const subjectRecords = attendanceRecords.filter(
    record => record.studentId === studentId && record.subjectId === subjectId
  );
  
  const totalClasses = subjectRecords.length;
  const attendedClasses = subjectRecords.filter(record => record.present).length;
  
  return {
    total: totalClasses,
    attended: attendedClasses,
    percentage: totalClasses > 0 ? (attendedClasses / totalClasses) * 100 : 0
  };
};

export const getAllSubjectsAttendance = (studentId: number) => {
  const result = [];
  
  for (let subjectId = 1; subjectId <= 5; subjectId++) {
    result.push({
      subjectId,
      attendance: getSubjectAttendance(studentId, subjectId)
    });
  }
  
  return result;
};

// Function to predict attendance trends
export const predictAttendanceDecrease = (studentId: number, threshold = 75) => {
  const studentRecords = attendanceRecords.filter(
    record => record.studentId === studentId
  );
  
  // Sort by date
  studentRecords.sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  // Get unique dates
  const uniqueDates = [...new Set(studentRecords.map(r => r.date))];
  
  // Calculate running attendance percentage
  const runningAttendance = uniqueDates.map((date, index) => {
    const recordsUntilDate = studentRecords.filter(
      r => new Date(r.date) <= new Date(date)
    );
    
    const total = recordsUntilDate.length;
    const present = recordsUntilDate.filter(r => r.present).length;
    
    return {
      date,
      percentage: (present / total) * 100
    };
  });
  
  // If already below threshold, return current date
  const currentPercentage = runningAttendance[runningAttendance.length - 1].percentage;
  if (currentPercentage < threshold) {
    return {
      currentPercentage,
      predictedDate: new Date().toISOString().split('T')[0],
      daysRemaining: 0
    };
  }
  
  // Simplified linear regression to predict future trend
  const xValues = runningAttendance.map((_, i) => i);
  const yValues = runningAttendance.map(item => item.percentage);
  
  // Calculate slope using last 10 data points
  let slope = 0;
  const recentXValues = xValues.slice(-10);
  const recentYValues = yValues.slice(-10);
  
  if (recentXValues.length >= 2) {
    const xMean = recentXValues.reduce((a, b) => a + b, 0) / recentXValues.length;
    const yMean = recentYValues.reduce((a, b) => a + b, 0) / recentYValues.length;
    
    let numerator = 0;
    let denominator = 0;
    
    for (let i = 0; i < recentXValues.length; i++) {
      numerator += (recentXValues[i] - xMean) * (recentYValues[i] - yMean);
      denominator += (recentXValues[i] - xMean) ** 2;
    }
    
    slope = denominator !== 0 ? numerator / denominator : 0;
  }
  
  // If slope is positive or zero, attendance is not decreasing
  if (slope >= 0) {
    return {
      currentPercentage,
      predictedDate: null,
      daysRemaining: null,
      isDecreasing: false
    };
  }
  
  // Calculate days until threshold is reached
  const daysRemaining = Math.ceil((threshold - currentPercentage) / slope);
  
  // Calculate predicted date
  const predictedDate = new Date();
  predictedDate.setDate(predictedDate.getDate() + daysRemaining);
  
  return {
    currentPercentage,
    predictedDate: predictedDate.toISOString().split('T')[0],
    daysRemaining: daysRemaining > 0 ? daysRemaining : 0,
    isDecreasing: true
  };
};