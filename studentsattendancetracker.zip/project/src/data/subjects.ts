import { Subject } from '../types';

// Course subjects
export const subjects: Subject[] = [
  { id: 1, name: 'Calculus', code: 'MATH101' },
  { id: 2, name: 'Semiconductor Physics', code: 'PHYS205' },
  { id: 3, name: 'Electrical and Electronics', code: 'EE101' },
  { id: 4, name: 'English', code: 'ENGL103' },
  { id: 5, name: 'Engineering Chemistry', code: 'CHEM104' }
];