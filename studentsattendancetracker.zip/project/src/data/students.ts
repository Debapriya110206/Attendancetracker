import { Student } from '../types';

// Pre-registered students with roll numbers and passwords
export const students: Student[] = [
  { id: 1, rollNumber: '123', password: 'student123', name: 'Alex Johnson' },
  { id: 2, rollNumber: '345', password: 'student345', name: 'Samantha Lee' },
  { id: 3, rollNumber: '456', password: 'student456', name: 'Michael Chen' },
  { id: 4, rollNumber: '567', password: 'student567', name: 'Emily Rodriguez' },
  { id: 5, rollNumber: '678', password: 'student678', name: 'David Kim' },
  { id: 6, rollNumber: '789', password: 'student789', name: 'Jessica Patel' },
  { id: 7, rollNumber: '890', password: 'student890', name: 'Ryan Wilson' },
  { id: 8, rollNumber: '901', password: 'student901', name: 'Sophia Taylor' },
  { id: 9, rollNumber: '112', password: 'student112', name: 'Daniel Martinez' },
  { id: 10, rollNumber: '223', password: 'student223', name: 'Olivia Anderson' },
  { id: 11, rollNumber: '334', password: 'student334', name: 'Ethan Brown' },
  { id: 12, rollNumber: '445', password: 'student445', name: 'Ava Thompson' },
  { id: 13, rollNumber: '556', password: 'student556', name: 'Noah Garcia' },
  { id: 14, rollNumber: '667', password: 'student667', name: 'Mia Davis' },
  { id: 15, rollNumber: '778', password: 'student778', name: 'William Smith' },
  { id: 16, rollNumber: '889', password: 'student889', name: 'Isabella Johnson' },
  { id: 17, rollNumber: '990', password: 'student990', name: 'James Wilson' },
  { id: 18, rollNumber: '111', password: 'student111', name: 'Charlotte Brown' },
  { id: 19, rollNumber: '222', password: 'student222', name: 'Benjamin Miller' },
  { id: 20, rollNumber: '333', password: 'student333', name: 'Amelia Davis' }
];