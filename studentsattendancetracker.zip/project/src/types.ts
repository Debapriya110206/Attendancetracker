// Student type
export interface Student {
  id: number;
  rollNumber: string;
  password: string;
  name: string;
}

// Subject type
export interface Subject {
  id: number;
  name: string;
  code: string;
}

// Attendance record type
export interface AttendanceRecord {
  id: number;
  studentId: number;
  subjectId: number;
  date: string;
  present: boolean;
}

// Auth context type
export interface AuthContextType {
  currentUser: Student | null;
  login: (rollNumber: string, password: string) => boolean;
  logout: () => void;
  isLoggedIn: boolean;
}

// Attendance stats type
export interface AttendanceStats {
  total: number;
  attended: number;
  percentage: number;
}

// Subject attendance type
export interface SubjectAttendance {
  subjectId: number;
  attendance: AttendanceStats;
}

// Attendance prediction type
export interface AttendancePrediction {
  currentPercentage: number;
  predictedDate: string | null;
  daysRemaining: number | null;
  isDecreasing?: boolean;
}