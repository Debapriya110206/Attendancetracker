import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, BookOpen, Calendar, BarChart, ClipboardList } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  return (
    <aside
      className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-800 shadow-md z-10 transition-all duration-300 ease-in-out ${
        isOpen ? 'translate-x-0 w-64' : '-translate-x-full w-64 md:translate-x-0 md:w-20'
      }`}
    >
      <div className="flex flex-col h-full py-4">
        <nav className="flex-1 px-2 space-y-1">
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `flex items-center px-3 py-3 text-gray-700 dark:text-gray-200 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`
            }
          >
            <Home className="flex-shrink-0 w-5 h-5" />
            <span className={`ml-3 font-medium ${!isOpen && 'md:hidden'}`}>Dashboard</span>
          </NavLink>
          
          <NavLink
            to="/subjects"
            className={({ isActive }) =>
              `flex items-center px-3 py-3 text-gray-700 dark:text-gray-200 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`
            }
          >
            <BookOpen className="flex-shrink-0 w-5 h-5" />
            <span className={`ml-3 font-medium ${!isOpen && 'md:hidden'}`}>Subjects</span>
          </NavLink>
          
          <NavLink
            to="/calendar"
            className={({ isActive }) =>
              `flex items-center px-3 py-3 text-gray-700 dark:text-gray-200 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`
            }
          >
            <Calendar className="flex-shrink-0 w-5 h-5" />
            <span className={`ml-3 font-medium ${!isOpen && 'md:hidden'}`}>Calendar</span>
          </NavLink>
          
          <NavLink
            to="/records"
            className={({ isActive }) =>
              `flex items-center px-3 py-3 text-gray-700 dark:text-gray-200 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`
            }
          >
            <ClipboardList className="flex-shrink-0 w-5 h-5" />
            <span className={`ml-3 font-medium ${!isOpen && 'md:hidden'}`}>Records</span>
          </NavLink>
          
          <NavLink
            to="/prediction"
            className={({ isActive }) =>
              `flex items-center px-3 py-3 text-gray-700 dark:text-gray-200 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`
            }
          >
            <BarChart className="flex-shrink-0 w-5 h-5" />
            <span className={`ml-3 font-medium ${!isOpen && 'md:hidden'}`}>Prediction</span>
          </NavLink>
        </nav>
        
        <div className="px-3 mt-6">
          <div className="rounded-md bg-blue-50 dark:bg-blue-900/20 p-3">
            <div className={`${!isOpen && 'md:hidden'}`}>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Need Help?</p>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                Contact your instructor or admin for assistance.
              </p>
            </div>
            <div className={`${isOpen && 'hidden'} md:block md:text-center`}>
              <p className="text-xs font-medium text-blue-800 dark:text-blue-300">Help</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;