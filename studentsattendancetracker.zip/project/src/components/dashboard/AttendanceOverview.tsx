import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getStudentAttendance } from '../../data/attendance';
import { CheckCircle as CircleCheck, Circle as CircleX } from 'lucide-react';

const AttendanceOverview: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  const attendance = getStudentAttendance(currentUser.id);
  
  // Determine status color based on attendance percentage
  const getStatusColor = (percentage: number) => {
    if (percentage >= 85) return 'text-green-500';
    if (percentage >= 75) return 'text-yellow-500';
    return 'text-red-500';
  };
  
  const statusColor = getStatusColor(attendance.percentage);
  
  // Determine status text
  const getStatusText = (percentage: number) => {
    if (percentage >= 85) return 'Excellent';
    if (percentage >= 75) return 'Good';
    return 'At Risk';
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Overall Attendance</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="space-y-3">
          <div className="flex items-center">
            <CircleCheck className="h-5 w-5 text-green-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-300">Classes Attended:</span>
            <span className="ml-auto font-medium text-gray-900 dark:text-white">{attendance.attended}</span>
          </div>
          
          <div className="flex items-center">
            <CircleX className="h-5 w-5 text-red-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-300">Classes Missed:</span>
            <span className="ml-auto font-medium text-gray-900 dark:text-white">{attendance.total - attendance.attended}</span>
          </div>
          
          <div className="flex items-center">
            <span className="text-gray-600 dark:text-gray-300">Total Classes:</span>
            <span className="ml-auto font-medium text-gray-900 dark:text-white">{attendance.total}</span>
          </div>
        </div>
        
        <div className="flex flex-col justify-center items-center">
          <div className="relative h-36 w-36">
            <svg className="h-full w-full" viewBox="0 0 36 36">
              <path
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#E5E7EB"
                strokeWidth="3"
                strokeDasharray="100, 100"
              />
              <path
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke={attendance.percentage >= 75 ? '#10B981' : '#EF4444'}
                strokeWidth="3"
                strokeDasharray={`${attendance.percentage}, 100`}
                className="animate-dash"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-gray-900 dark:text-white">{Math.round(attendance.percentage)}%</span>
              <span className={`text-sm font-medium ${statusColor}`}>{getStatusText(attendance.percentage)}</span>
            </div>
          </div>
          
          <p className="mt-4 text-sm text-gray-600 dark:text-gray-400 text-center">
            {attendance.percentage >= 75 
              ? 'Your attendance is on track!'
              : 'Your attendance is below the required 75%.'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AttendanceOverview;