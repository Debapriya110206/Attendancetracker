import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { predictAttendanceDecrease } from '../../data/attendance';
import { Calendar, TrendingDown, TrendingUp, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

const PredictionWidget: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  const prediction = predictAttendanceDecrease(currentUser.id);
  
  // Format date
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Attendance Prediction</h2>
      
      <div className="flex items-center mb-4">
        {prediction.isDecreasing ? (
          <div className="p-3 bg-amber-100 dark:bg-amber-900/20 rounded-full mr-4">
            <TrendingDown className="h-6 w-6 text-amber-500 dark:text-amber-400" />
          </div>
        ) : (
          <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-full mr-4">
            <TrendingUp className="h-6 w-6 text-green-500 dark:text-green-400" />
          </div>
        )}
        
        <div>
          <h3 className="font-medium text-gray-800 dark:text-white">
            {prediction.isDecreasing
              ? 'Your attendance is declining'
              : 'Your attendance is stable'}
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Current attendance: {Math.round(prediction.currentPercentage)}%
          </p>
        </div>
      </div>
      
      {prediction.isDecreasing && prediction.predictedDate && (
        <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-md">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-amber-500 dark:text-amber-400 mt-0.5 mr-2 flex-shrink-0" />
            <div>
              <p className="text-gray-800 dark:text-white text-sm">
                If your attendance trend continues, you may fall below the required 75% threshold by:
              </p>
              <div className="flex items-center mt-2">
                <Calendar className="h-4 w-4 text-gray-500 dark:text-gray-400 mr-1" />
                <span className="text-gray-900 dark:text-white font-medium">
                  {formatDate(prediction.predictedDate)}
                </span>
                <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                  ({prediction.daysRemaining} days from now)
                </span>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <Link 
              to="/prediction"
              className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
            >
              View detailed prediction analysis →
            </Link>
          </div>
        </div>
      )}
      
      {!prediction.isDecreasing && (
        <div className="bg-green-50 dark:bg-green-900/10 p-4 rounded-md">
          <div className="flex items-start">
            <div className="p-1 bg-green-100 dark:bg-green-800 rounded-full mr-2">
              <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-300" />
            </div>
            <div>
              <p className="text-gray-800 dark:text-white text-sm">
                Your attendance trend is positive! 
                Keep up the good work to maintain above the required 75% threshold.
              </p>
            </div>
          </div>
          
          <div className="mt-4">
            <Link 
              to="/prediction"
              className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
            >
              View detailed attendance analysis →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionWidget;