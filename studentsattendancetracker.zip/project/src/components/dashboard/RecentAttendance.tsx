import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { attendanceRecords } from '../../data/attendance';
import { subjects } from '../../data/subjects';
import { CheckCircle as CircleCheck, Circle as CircleX } from 'lucide-react';

const RecentAttendance: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get recent attendance records for the current user
  const recentRecords = [...attendanceRecords]
    .filter(record => record.studentId === currentUser.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10); // Get only the 10 most recent records
  
  // Group records by date
  const groupedRecords: Record<string, typeof recentRecords> = {};
  
  recentRecords.forEach(record => {
    if (!groupedRecords[record.date]) {
      groupedRecords[record.date] = [];
    }
    groupedRecords[record.date].push(record);
  });
  
  // Sort dates in descending order
  const sortedDates = Object.keys(groupedRecords).sort(
    (a, b) => new Date(b).getTime() - new Date(a).getTime()
  );
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };
  
  // Get subject name
  const getSubjectName = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Recent Attendance</h2>
      
      {sortedDates.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">No recent attendance records found.</p>
      ) : (
        <div className="space-y-6">
          {sortedDates.slice(0, 3).map(date => (
            <div key={date} className="border-b border-gray-200 dark:border-gray-700 pb-4 last:border-0 last:pb-0">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-800 dark:text-white">{formatDate(date)}</h3>
              </div>
              
              <div className="space-y-2">
                {groupedRecords[date].map(record => (
                  <div 
                    key={record.id}
                    className="flex items-center py-2 px-3 bg-gray-50 dark:bg-gray-700/50 rounded-md"
                  >
                    {record.present ? (
                      <CircleCheck className="h-5 w-5 text-green-500 mr-3" />
                    ) : (
                      <CircleX className="h-5 w-5 text-red-500 mr-3" />
                    )}
                    <span className="text-gray-800 dark:text-white">{getSubjectName(record.subjectId)}</span>
                    <span className="ml-auto text-sm text-gray-500 dark:text-gray-400">
                      {record.present ? 'Present' : 'Absent'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RecentAttendance;