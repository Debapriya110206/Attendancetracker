import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllSubjectsAttendance } from '../../data/attendance';
import { subjects } from '../../data/subjects';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const SubjectSummary: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  const subjectsAttendance = getAllSubjectsAttendance(currentUser.id);
  
  // Get subject name
  const getSubjectName = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };
  
  // Get subject code
  const getSubjectCode = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.code : '';
  };
  
  // Get color based on attendance percentage
  const getStatusColor = (percentage: number) => {
    if (percentage >= 85) return 'bg-green-500';
    if (percentage >= 75) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Subject-wise Attendance</h2>
        <Link 
          to="/subjects"
          className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 flex items-center"
        >
          View All <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </div>
      
      <div className="space-y-4">
        {subjectsAttendance.map(item => (
          <div key={item.subjectId} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-md">
            <div className="flex justify-between items-center mb-2">
              <div>
                <h3 className="font-medium text-gray-800 dark:text-white">{getSubjectName(item.subjectId)}</h3>
                <span className="text-xs text-gray-500 dark:text-gray-400">{getSubjectCode(item.subjectId)}</span>
              </div>
              <span className="text-base font-semibold text-gray-800 dark:text-white">
                {Math.round(item.attendance.percentage)}%
              </span>
            </div>
            
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-2 rounded-full transition-all duration-500 ${getStatusColor(item.attendance.percentage)}`}
                style={{ width: `${item.attendance.percentage}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between text-xs mt-2">
              <span className="text-gray-500 dark:text-gray-400">
                {item.attendance.attended}/{item.attendance.total} classes
              </span>
              <span className={`
                ${item.attendance.percentage >= 75 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}
                font-medium
              `}>
                {item.attendance.percentage >= 75 ? 'On Track' : 'Attendance Low'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubjectSummary;