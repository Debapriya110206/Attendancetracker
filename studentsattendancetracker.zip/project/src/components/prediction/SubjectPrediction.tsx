import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { subjects } from '../../data/subjects';
import { getSubjectAttendance, attendanceRecords } from '../../data/attendance';
import { ArrowDown, ArrowUp } from 'lucide-react';

const SubjectPrediction: React.FC = () => {
  const { currentUser } = useAuth();
  const [sortBy, setSortBy] = useState<'name' | 'percentage'>('percentage');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get trend for each subject
  const getSubjectTrend = (subjectId: number) => {
    const records = attendanceRecords.filter(
      record => record.studentId === currentUser.id && record.subjectId === subjectId
    );
    
    if (records.length < 6) return 0;
    
    // Sort by date
    records.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    // Split into two halves (first half and second half)
    const midpoint = Math.floor(records.length / 2);
    const firstHalf = records.slice(0, midpoint);
    const secondHalf = records.slice(midpoint);
    
    // Calculate attendance percentage for each half
    const firstHalfAttendance = firstHalf.filter(r => r.present).length / firstHalf.length;
    const secondHalfAttendance = secondHalf.filter(r => r.present).length / secondHalf.length;
    
    // Return the difference (positive means improving, negative means declining)
    return (secondHalfAttendance - firstHalfAttendance) * 100;
  };
  
  // Get predicted percentage
  const getPredictedPercentage = (subjectId: number) => {
    const currentAttendance = getSubjectAttendance(currentUser.id, subjectId);
    const trend = getSubjectTrend(subjectId);
    
    // Simple prediction: current + (trend/2)
    // This dampens the trend effect to avoid extreme predictions
    return Math.min(Math.max(currentAttendance.percentage + trend/2, 0), 100);
  };
  
  // Prepare subject data
  const subjectData = subjects.map(subject => {
    const attendance = getSubjectAttendance(currentUser.id, subject.id);
    const trend = getSubjectTrend(subject.id);
    const predicted = getPredictedPercentage(subject.id);
    
    return {
      id: subject.id,
      name: subject.name,
      code: subject.code,
      current: attendance.percentage,
      trend,
      predicted
    };
  });
  
  // Sort subject data
  const sortedData = [...subjectData].sort((a, b) => {
    if (sortBy === 'name') {
      return sortOrder === 'asc' 
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    } else {
      return sortOrder === 'asc'
        ? a.current - b.current
        : b.current - a.current;
    }
  });
  
  // Handle sort change
  const handleSort = (column: 'name' | 'percentage') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Subject-wise Prediction</h2>
      
      <div className="overflow-hidden border border-gray-200 dark:border-gray-700 rounded-lg mb-4">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('name')}
              >
                <div className="flex items-center">
                  Subject
                  {sortBy === 'name' && (
                    sortOrder === 'asc' ? 
                    <ArrowUp className="h-3 w-3 ml-1" /> :
                    <ArrowDown className="h-3 w-3 ml-1" />
                  )}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('percentage')}
              >
                <div className="flex items-center">
                  Current
                  {sortBy === 'percentage' && (
                    sortOrder === 'asc' ? 
                    <ArrowUp className="h-3 w-3 ml-1" /> :
                    <ArrowDown className="h-3 w-3 ml-1" />
                  )}
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Trend
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Predicted
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {sortedData.map(subject => (
              <tr key={subject.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">{subject.name}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">{subject.code}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className={`text-sm font-medium ${
                    subject.current >= 75 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                  }`}>
                    {Math.round(subject.current)}%
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {subject.trend > 1 ? (
                    <div className="flex items-center text-green-600 dark:text-green-400">
                      <ArrowUp className="h-4 w-4 mr-1" />
                      <span className="text-sm">+{Math.round(subject.trend)}%</span>
                    </div>
                  ) : subject.trend < -1 ? (
                    <div className="flex items-center text-red-600 dark:text-red-400">
                      <ArrowDown className="h-4 w-4 mr-1" />
                      <span className="text-sm">{Math.round(subject.trend)}%</span>
                    </div>
                  ) : (
                    <div className="text-sm text-gray-500 dark:text-gray-400">Stable</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className={`text-sm font-medium ${
                    subject.predicted >= 75 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                  }`}>
                    {Math.round(subject.predicted)}%
                  </div>
                  <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mt-1">
                    <div
                      className={`h-1.5 rounded-full ${subject.predicted >= 75 ? 'bg-green-500' : 'bg-red-500'}`}
                      style={{ width: `${Math.min(Math.max(subject.predicted, 0), 100)}%` }}
                    ></div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="space-y-4">
        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
          <h3 className="font-medium text-blue-800 dark:text-blue-300 mb-2">How to Interpret</h3>
          <ul className="text-sm text-blue-700 dark:text-blue-400 space-y-1 list-disc list-inside">
            <li><strong>Current:</strong> Your current attendance percentage</li>
            <li><strong>Trend:</strong> Whether your attendance is improving or declining</li>
            <li><strong>Predicted:</strong> Expected percentage if current pattern continues</li>
          </ul>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
          <h3 className="font-medium text-gray-800 dark:text-white mb-2">Action Plan</h3>
          <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
            {sortedData.filter(s => s.predicted < 75).map(subject => (
              <li key={subject.id} className="flex items-start">
                <span className="inline-block w-3 h-3 rounded-full bg-red-500 mt-1 mr-2"></span>
                <span>
                  <strong>{subject.name}:</strong> Focus on improving attendance to avoid falling below 75%.
                </span>
              </li>
            ))}
            {sortedData.filter(s => s.predicted < 75).length === 0 && (
              <li className="flex items-start">
                <span className="inline-block w-3 h-3 rounded-full bg-green-500 mt-1 mr-2"></span>
                <span>All subjects are predicted to maintain attendance above 75%. Keep up the good work!</span>
              </li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SubjectPrediction;