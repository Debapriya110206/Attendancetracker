import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { attendanceRecords } from '../../data/attendance';
import { TrendingDown, TrendingUp, AlertTriangle } from 'lucide-react';

const PredictionChart: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get attendance history for chart
  const getAttendanceHistory = () => {
    const studentRecords = attendanceRecords.filter(
      record => record.studentId === currentUser.id
    );
    
    // Sort by date
    studentRecords.sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    // Get unique dates
    const uniqueDates = [...new Set(studentRecords.map(r => r.date))];
    
    // Calculate running attendance percentage
    return uniqueDates.map((date, index) => {
      const recordsUntilDate = studentRecords.filter(
        r => new Date(r.date) <= new Date(date)
      );
      
      const total = recordsUntilDate.length;
      const present = recordsUntilDate.filter(r => r.present).length;
      
      return {
        date,
        percentage: (present / total) * 100
      };
    });
  };
  
  const attendanceHistory = getAttendanceHistory();
  
  // Calculate trend
  const calculateTrend = () => {
    if (attendanceHistory.length < 5) return 0;
    
    const recentData = attendanceHistory.slice(-5);
    
    return recentData[recentData.length - 1].percentage - recentData[0].percentage;
  };
  
  const trend = calculateTrend();
  
  // Predict future points (simple linear extrapolation)
  const predictFuturePoints = () => {
    if (attendanceHistory.length < 5) return [];
    
    const recentData = attendanceHistory.slice(-10);
    
    // Calculate average change
    let totalChange = 0;
    for (let i = 1; i < recentData.length; i++) {
      totalChange += recentData[i].percentage - recentData[i-1].percentage;
    }
    
    const avgChange = totalChange / (recentData.length - 1);
    
    // Last actual percentage
    const lastPercentage = recentData[recentData.length - 1].percentage;
    const lastDate = new Date(recentData[recentData.length - 1].date);
    
    // Generate future points
    const futurePoints = [];
    
    for (let i = 1; i <= 10; i++) {
      const futureDate = new Date(lastDate);
      futureDate.setDate(lastDate.getDate() + i * 7); // Weekly projection
      
      futurePoints.push({
        date: futureDate.toISOString().split('T')[0],
        percentage: lastPercentage + (avgChange * i)
      });
    }
    
    return futurePoints;
  };
  
  const futurePoints = predictFuturePoints();
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };
  
  // Calculate max value for chart scaling
  const allValues = [...attendanceHistory, ...futurePoints].map(p => p.percentage);
  const maxValue = Math.max(...allValues, 100);
  const minValue = Math.min(...allValues, 50, 75);
  
  // Find when attendance crosses 75% threshold
  const findCriticalPoint = () => {
    if (futurePoints.length === 0) return null;
    
    const currentPercentage = attendanceHistory[attendanceHistory.length - 1].percentage;
    
    // If already below threshold
    if (currentPercentage < 75) return {
      date: attendanceHistory[attendanceHistory.length - 1].date,
      percentage: currentPercentage
    };
    
    // Find first point below threshold
    for (let i = 0; i < futurePoints.length; i++) {
      if (futurePoints[i].percentage < 75) {
        return futurePoints[i];
      }
    }
    
    return null;
  };
  
  const criticalPoint = findCriticalPoint();
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Attendance Prediction</h2>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Based on your current attendance pattern
          </p>
        </div>
        
        <div className="flex items-center">
          {trend > 0 ? (
            <div className="flex items-center text-green-600 dark:text-green-400">
              <TrendingUp className="h-5 w-5 mr-1" />
              <span>Improving</span>
            </div>
          ) : trend < 0 ? (
            <div className="flex items-center text-red-600 dark:text-red-400">
              <TrendingDown className="h-5 w-5 mr-1" />
              <span>Declining</span>
            </div>
          ) : (
            <div className="flex items-center text-gray-600 dark:text-gray-400">
              <span>Stable</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Chart */}
      <div className="h-72 relative mb-6">
        {/* 75% Threshold Line */}
        <div
          className="absolute border-t-2 border-dashed border-amber-500 dark:border-amber-400 w-full left-0 z-10"
          style={{
            top: `${100 - ((75 - minValue) / (maxValue - minValue)) * 100}%`
          }}
        >
          <div className="absolute -top-3 -right-1 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 text-xs px-1 rounded">
            75%
          </div>
        </div>
        
        {/* Chart Container */}
        <svg className="w-full h-full overflow-visible">
          {/* Actual Attendance Line */}
          <polyline
            points={attendanceHistory
              .map((point, index) => {
                const x = (index / (attendanceHistory.length - 1)) * 80;
                const y = 100 - ((point.percentage - minValue) / (maxValue - minValue)) * 100;
                return `${x},${y}`;
              })
              .join(' ')
            }
            fill="none"
            stroke="#3B82F6"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="drop-shadow"
          />
          
          {/* Future Prediction Line (Dashed) */}
          {futurePoints.length > 0 && (
            <polyline
              points={[
                ...futurePoints.map((point, index) => {
                  const x = 80 + ((index + 1) / (futurePoints.length)) * 20;
                  const y = 100 - ((point.percentage - minValue) / (maxValue - minValue)) * 100;
                  return `${x},${y}`;
                })
              ].join(' ')}
              fill="none"
              stroke="#3B82F6"
              strokeWidth="2"
              strokeDasharray="4,4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          
          {/* Critical Point Marker */}
          {criticalPoint && trend < 0 && (
            <circle
              cx={`${80 + ((futurePoints.findIndex(p => p.date === criticalPoint.date) + 1) / futurePoints.length) * 20}`}
              cy={`${100 - ((criticalPoint.percentage - minValue) / (maxValue - minValue)) * 100}`}
              r="4"
              fill="#EF4444"
              stroke="#FFFFFF"
              strokeWidth="2"
            />
          )}
          
          {/* Last Actual Point Marker */}
          <circle
            cx="80"
            cy={`${100 - ((attendanceHistory[attendanceHistory.length - 1].percentage - minValue) / (maxValue - minValue)) * 100}`}
            r="4"
            fill="#3B82F6"
            stroke="#FFFFFF"
            strokeWidth="2"
          />
        </svg>
        
        {/* X-Axis Labels */}
        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-2">
          <span>{formatDate(attendanceHistory[0]?.date || '')}</span>
          <span>Now</span>
          <span>Future</span>
        </div>
      </div>
      
      {/* Prediction Analysis */}
      {criticalPoint && trend < 0 ? (
        <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5 mr-2" />
            <div>
              <h3 className="font-medium text-red-800 dark:text-red-300">Attendance Warning</h3>
              <p className="text-sm text-red-700 dark:text-red-400 mt-1">
                At your current attendance pattern, you may fall below the required 75% threshold 
                by <strong>{formatDate(criticalPoint.date)}</strong>.
              </p>
              <div className="mt-3">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Recommendations:</p>
                <ul className="text-sm text-gray-600 dark:text-gray-400 list-disc list-inside mt-1 space-y-1">
                  <li>Attend all remaining classes this semester</li>
                  <li>Contact your instructor if you have extenuating circumstances</li>
                  <li>Set reminders for class timings</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
          <div className="flex items-start">
            <TrendingUp className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5 mr-2" />
            <div>
              <h3 className="font-medium text-green-800 dark:text-green-300">Attendance on Track</h3>
              <p className="text-sm text-green-700 dark:text-green-400 mt-1">
                Based on your current attendance pattern, you are likely to maintain above the required 75% threshold.
              </p>
              <div className="mt-3">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Recommendations:</p>
                <ul className="text-sm text-gray-600 dark:text-gray-400 list-disc list-inside mt-1 space-y-1">
                  <li>Continue your current attendance pattern</li>
                  <li>Focus on subjects with lower attendance if any</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionChart;