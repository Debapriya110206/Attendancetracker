import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { attendanceRecords } from '../../data/attendance';
import { subjects } from '../../data/subjects';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';

const AttendanceCalendar: React.FC = () => {
  const { currentUser } = useAuth();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get records for the current student
  const studentRecords = attendanceRecords.filter(record => record.studentId === currentUser.id);
  
  // Generate calendar grid
  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    // Get first day of the month
    const firstDay = new Date(year, month, 1);
    // Get last day of the month
    const lastDay = new Date(year, month + 1, 0);
    
    // Day of week for the first day (0 = Sunday, 1 = Monday, etc.)
    const firstDayOfWeek = firstDay.getDay();
    // Total days in month
    const daysInMonth = lastDay.getDate();
    
    // Create array for all days in the month
    const days = [];
    
    // Add days from previous month to fill the first week
    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push({ date: null, isCurrentMonth: false });
    }
    
    // Add all days of the current month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateString = date.toISOString().split('T')[0];
      
      // Get attendance records for this day
      const dayRecords = studentRecords.filter(record => record.date === dateString);
      
      days.push({
        date,
        isCurrentMonth: true,
        records: dayRecords,
        isToday: isToday(date)
      });
    }
    
    return days;
  };
  
  const days = generateCalendarDays();
  
  // Check if a date is today
  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear();
  };
  
  // Navigate to previous month
  const goToPreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };
  
  // Navigate to next month
  const goToNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };
  
  // Navigate to current month
  const goToCurrentMonth = () => {
    setCurrentMonth(new Date());
  };
  
  // Format month and year
  const formatMonthYear = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };
  
  // Get subject name
  const getSubjectName = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown';
  };
  
  // Day of week labels
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  // Get attendance status for a day
  const getDayAttendanceStatus = (records: typeof studentRecords | undefined) => {
    if (!records || records.length === 0) return 'none';
    
    const presentCount = records.filter(r => r.present).length;
    const totalCount = records.length;
    
    if (presentCount === totalCount) return 'full';
    if (presentCount === 0) return 'none';
    return 'partial';
  };
  
  // Get bg color for day based on attendance
  const getDayColor = (status: string) => {
    switch (status) {
      case 'full': return 'bg-green-100 dark:bg-green-900/20';
      case 'partial': return 'bg-yellow-100 dark:bg-yellow-900/20';
      case 'none': return 'bg-red-100 dark:bg-red-900/20';
      default: return '';
    }
  };
  
  // Get icon for day based on attendance
  const getDayIcon = (status: string) => {
    switch (status) {
      case 'full': return <div className="h-2 w-2 bg-green-500 rounded-full"></div>;
      case 'partial': return <div className="h-2 w-2 bg-yellow-500 rounded-full"></div>;
      case 'none': return <div className="h-2 w-2 bg-red-500 rounded-full"></div>;
      default: return null;
    }
  };
  
  // Selected day state
  const [selectedDay, setSelectedDay] = useState<{
    date: Date;
    records: typeof studentRecords;
  } | null>(null);
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex flex-col md:flex-row md:items-start md:space-x-6">
        <div className="w-full md:w-7/12">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Attendance Calendar</h2>
            <div className="flex items-center space-x-2">
              <button 
                onClick={goToPreviousMonth}
                className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <ChevronLeft className="h-5 w-5 text-gray-500 dark:text-gray-400" />
              </button>
              <button
                onClick={goToCurrentMonth}
                className="px-3 py-1 text-sm bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-md hover:bg-blue-100 dark:hover:bg-blue-900/40"
              >
                Today
              </button>
              <button 
                onClick={goToNextMonth}
                className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <ChevronRight className="h-5 w-5 text-gray-500 dark:text-gray-400" />
              </button>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex items-center justify-center">
              <h3 className="text-lg font-medium text-gray-800 dark:text-white">
                {formatMonthYear(currentMonth)}
              </h3>
            </div>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-2">
            {weekdays.map(day => (
              <div 
                key={day} 
                className="text-center text-xs text-gray-500 dark:text-gray-400 font-medium py-1"
              >
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {days.map((day, index) => {
              if (!day.date) {
                return (
                  <div 
                    key={`empty-${index}`}
                    className="h-16 p-1 rounded-md bg-gray-50 dark:bg-gray-700/30"
                  ></div>
                );
              }
              
              const attendanceStatus = getDayAttendanceStatus(day.records);
              
              return (
                <div 
                  key={day.date.toString()}
                  className={`h-16 p-2 rounded-md border border-gray-100 dark:border-gray-700 overflow-hidden 
                    ${day.isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-700/30'}
                    ${day.isToday ? 'ring-2 ring-blue-500 dark:ring-blue-400' : ''}
                    ${day.records && day.records.length > 0 ? getDayColor(attendanceStatus) : ''}
                    cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700
                  `}
                  onClick={() => setSelectedDay({
                    date: day.date,
                    records: day.records || []
                  })}
                >
                  <div className="flex justify-between items-start">
                    <span className={`text-sm font-medium ${
                      day.isToday ? 'text-blue-600 dark:text-blue-400' : 'text-gray-700 dark:text-gray-300'
                    }`}>
                      {day.date.getDate()}
                    </span>
                    {day.records && day.records.length > 0 && getDayIcon(attendanceStatus)}
                  </div>
                  
                  {day.records && day.records.length > 0 && (
                    <div className="mt-1 overflow-hidden">
                      <div className="text-xs text-gray-600 dark:text-gray-400 truncate">
                        {day.records.length} class{day.records.length !== 1 ? 'es' : ''}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="flex items-center justify-center mt-4 space-x-4 text-sm">
            <div className="flex items-center">
              <div className="h-3 w-3 bg-green-500 rounded-full mr-1"></div>
              <span className="text-gray-700 dark:text-gray-300">All Present</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 bg-yellow-500 rounded-full mr-1"></div>
              <span className="text-gray-700 dark:text-gray-300">Partial</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 bg-red-500 rounded-full mr-1"></div>
              <span className="text-gray-700 dark:text-gray-300">All Absent</span>
            </div>
          </div>
        </div>
        
        <div className="w-full md:w-5/12 mt-6 md:mt-0">
          {selectedDay ? (
            <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <CalendarIcon className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-2" />
                  <h3 className="font-medium text-gray-800 dark:text-white">
                    {selectedDay.date.toLocaleDateString('en-US', {
                      weekday: 'long',
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedDay(null)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  &times;
                </button>
              </div>
              
              {selectedDay.records.length > 0 ? (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Attendance Records:</h4>
                  <div className="space-y-2">
                    {selectedDay.records.map(record => (
                      <div 
                        key={record.id}
                        className={`rounded-md p-2 ${record.present ? 
                          'bg-green-100 dark:bg-green-900/30 border-l-4 border-green-500' : 
                          'bg-red-100 dark:bg-red-900/30 border-l-4 border-red-500'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-gray-800 dark:text-white">
                            {getSubjectName(record.subjectId)}
                          </span>
                          <span className={`text-sm ${
                            record.present ? 
                              'text-green-700 dark:text-green-400' : 
                              'text-red-700 dark:text-red-400'
                          }`}>
                            {record.present ? 'Present' : 'Absent'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500 dark:text-gray-400">No attendance records for this day.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 flex flex-col items-center justify-center h-64">
              <CalendarIcon className="h-12 w-12 text-blue-500 dark:text-blue-400 mb-4" />
              <p className="text-center text-blue-700 dark:text-blue-300">
                Select a day from the calendar to view attendance details
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AttendanceCalendar;