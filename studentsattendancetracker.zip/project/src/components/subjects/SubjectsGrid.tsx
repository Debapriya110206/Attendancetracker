import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllSubjectsAttendance } from '../../data/attendance';
import { subjects } from '../../data/subjects';
import { BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

const SubjectsGrid: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  const subjectsAttendance = getAllSubjectsAttendance(currentUser.id);
  
  // Get subject name
  const getSubject = (subjectId: number) => {
    return subjects.find(s => s.id === subjectId);
  };
  
  // Get color based on attendance percentage
  const getStatusColor = (percentage: number) => {
    if (percentage >= 85) return 'border-green-500 bg-green-50 dark:bg-green-900/20';
    if (percentage >= 75) return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20';
    return 'border-red-500 bg-red-50 dark:bg-red-900/20';
  };
  
  // Get progress bar color
  const getProgressColor = (percentage: number) => {
    if (percentage >= 85) return 'bg-green-500';
    if (percentage >= 75) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  // Get status text
  const getStatusText = (percentage: number) => {
    if (percentage >= 85) return 'Excellent';
    if (percentage >= 75) return 'Good';
    return 'At Risk';
  };
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {subjectsAttendance.map(item => {
        const subject = getSubject(item.subjectId);
        
        return (
          <Link
            key={item.subjectId}
            to={`/subjects/${item.subjectId}`}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border-l-4 hover:shadow-md transition-shadow border-gray-200 dark:border-gray-700"
          >
            <div className={`p-5 border-b ${getStatusColor(item.attendance.percentage)}`}>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center">
                  <BookOpen className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-2" />
                  <h3 className="font-semibold text-gray-800 dark:text-white">{subject?.name}</h3>
                </div>
                <span className="text-xl font-bold text-gray-800 dark:text-white">
                  {Math.round(item.attendance.percentage)}%
                </span>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{subject?.code}</p>
              
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-2">
                <div
                  className={`h-2.5 rounded-full ${getProgressColor(item.attendance.percentage)}`}
                  style={{ width: `${item.attendance.percentage}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">
                  {item.attendance.attended}/{item.attendance.total} classes
                </span>
                <span className="font-medium text-gray-800 dark:text-gray-200">
                  {getStatusText(item.attendance.percentage)}
                </span>
              </div>
            </div>
            
            <div className="p-4 bg-white dark:bg-gray-800">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {item.attendance.percentage < 75 ? (
                  <span>Need to improve attendance</span>
                ) : (
                  <span>Attendance on track</span>
                )}
              </p>
              <div className="text-right">
                <span className="text-sm text-blue-600 dark:text-blue-400 font-medium">View Details →</span>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
};

export default SubjectsGrid;