import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getSubjectAttendance, attendanceRecords } from '../../data/attendance';
import { subjects } from '../../data/subjects';
import { BarChart, Calendar, AlertCircle, Check, X } from 'lucide-react';

interface SubjectDetailProps {
  subjectId: number;
}

const SubjectDetail: React.FC<SubjectDetailProps> = ({ subjectId }) => {
  const { currentUser } = useAuth();
  const [viewType, setViewType] = useState<'overview' | 'records'>('overview');
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get subject info
  const subject = subjects.find(s => s.id === subjectId);
  if (!subject) {
    return (
      <div className="p-6 bg-red-50 dark:bg-red-900/20 rounded-lg">
        <div className="flex items-center">
          <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
          <h3 className="text-red-700 dark:text-red-400 font-medium">Subject not found</h3>
        </div>
      </div>
    );
  }
  
  // Get attendance data
  const attendance = getSubjectAttendance(currentUser.id, subjectId);
  
  // Get attendance records for this subject
  const subjectRecords = [...attendanceRecords]
    .filter(record => record.studentId === currentUser.id && record.subjectId === subjectId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  // Group records by month for chart
  const getMonthlyData = () => {
    const monthlyData: Record<string, { present: number; absent: number }> = {};
    
    subjectRecords.forEach(record => {
      const monthYear = new Date(record.date).toLocaleDateString('en-US', {
        month: 'short',
        year: 'numeric'
      });
      
      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = { present: 0, absent: 0 };
      }
      
      if (record.present) {
        monthlyData[monthYear].present += 1;
      } else {
        monthlyData[monthYear].absent += 1;
      }
    });
    
    return Object.entries(monthlyData)
      .slice(0, 3) // Get last 3 months
      .reverse(); // Show in chronological order
  };
  
  // Calculate attendance streak
  const calculateStreak = () => {
    let currentStreak = 0;
    const sortedRecords = [...subjectRecords].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    for (let i = sortedRecords.length - 1; i >= 0; i--) {
      if (sortedRecords[i].present) {
        currentStreak++;
      } else {
        break;
      }
    }
    
    return currentStreak;
  };
  
  const streak = calculateStreak();
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">{subject.name}</h2>
            <p className="text-gray-500 dark:text-gray-400">{subject.code}</p>
          </div>
          
          <div className="mt-4 sm:mt-0 flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setViewType('overview')}
              className={`px-4 py-2 text-sm font-medium rounded-md ${
                viewType === 'overview'
                  ? 'bg-white dark:bg-gray-600 shadow text-blue-600 dark:text-blue-400'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white'
              }`}
            >
              <span className="flex items-center">
                <BarChart className="h-4 w-4 mr-1.5" />
                Overview
              </span>
            </button>
            <button
              onClick={() => setViewType('records')}
              className={`px-4 py-2 text-sm font-medium rounded-md ${
                viewType === 'records'
                  ? 'bg-white dark:bg-gray-600 shadow text-blue-600 dark:text-blue-400'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white'
              }`}
            >
              <span className="flex items-center">
                <Calendar className="h-4 w-4 mr-1.5" />
                Records
              </span>
            </button>
          </div>
        </div>
        
        {viewType === 'overview' ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <h3 className="text-blue-700 dark:text-blue-400 font-medium mb-1">Overall Attendance</h3>
                <p className="text-3xl font-bold text-blue-800 dark:text-blue-300">
                  {Math.round(attendance.percentage)}%
                </p>
                <p className="text-sm text-blue-600 dark:text-blue-500 mt-1">
                  {attendance.attended} out of {attendance.total} classes
                </p>
              </div>
              
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <h3 className="text-green-700 dark:text-green-400 font-medium mb-1">Classes Attended</h3>
                <p className="text-3xl font-bold text-green-800 dark:text-green-300">
                  {attendance.attended}
                </p>
                <p className="text-sm text-green-600 dark:text-green-500 mt-1">
                  {Math.round((attendance.attended / attendance.total) * 100)}% of total classes
                </p>
              </div>
              
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
                <h3 className="text-red-700 dark:text-red-400 font-medium mb-1">Classes Missed</h3>
                <p className="text-3xl font-bold text-red-800 dark:text-red-300">
                  {attendance.total - attendance.attended}
                </p>
                <p className="text-sm text-red-600 dark:text-red-500 mt-1">
                  {Math.round(((attendance.total - attendance.attended) / attendance.total) * 100)}% of total classes
                </p>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
              <h3 className="font-medium text-gray-800 dark:text-white mb-4">Monthly Attendance</h3>
              
              <div className="h-64">
                {getMonthlyData().length > 0 ? (
                  <div className="h-full flex items-end justify-around">
                    {getMonthlyData().map(([month, data]) => {
                      const total = data.present + data.absent;
                      const presentPercentage = Math.round((data.present / total) * 100);
                      const absentPercentage = Math.round((data.absent / total) * 100);
                      
                      return (
                        <div key={month} className="flex flex-col items-center mx-2">
                          <div className="w-full flex justify-center space-x-1 mb-2">
                            <div
                              className="w-16 bg-green-400 dark:bg-green-500 rounded-t"
                              style={{ height: `${presentPercentage * 2}px` }}
                            ></div>
                            <div
                              className="w-16 bg-red-400 dark:bg-red-500 rounded-t"
                              style={{ height: `${absentPercentage * 2}px` }}
                            ></div>
                          </div>
                          <div className="text-xs text-gray-600 dark:text-gray-400">{month}</div>
                          <div className="text-xs mt-1">
                            <span className="text-green-600 dark:text-green-400">{data.present}</span> /
                            <span className="text-red-600 dark:text-red-400"> {data.absent}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-gray-500 dark:text-gray-400">No data available for chart</p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-800 dark:text-white mb-3">Classes Required for 75%</h3>
                
                {attendance.percentage >= 75 ? (
                  <div className="flex items-center text-green-600 dark:text-green-400">
                    <Check className="h-5 w-5 mr-2" />
                    <p>You are already above the required attendance threshold!</p>
                  </div>
                ) : (
                  <div>
                    <p className="text-gray-700 dark:text-gray-300">
                      To reach 75% attendance, you need to attend at least:
                    </p>
                    <p className="text-xl font-bold mt-2 text-blue-600 dark:text-blue-400">
                      {Math.ceil((0.75 * attendance.total - attendance.attended) / (1 - 0.75))} more consecutive classes
                    </p>
                  </div>
                )}
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-800 dark:text-white mb-3">Current Streak</h3>
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900/30 mr-3">
                    <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-gray-800 dark:text-white">{streak} {streak === 1 ? 'class' : 'classes'}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Current attendance streak</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <div className="overflow-hidden border border-gray-200 dark:border-gray-700 rounded-lg">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {subjectRecords.map(record => (
                    <tr key={record.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-white">
                        {formatDate(record.date)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {record.present ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                            <Check className="h-3 w-3 mr-1" /> Present
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200">
                            <X className="h-3 w-3 mr-1" /> Absent
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubjectDetail;