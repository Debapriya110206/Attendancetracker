import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { attendanceRecords } from '../data/attendance';
import { subjects } from '../data/subjects';
import { Search, Filter, Check, X, Calendar } from 'lucide-react';

const RecordsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSubject, setFilterSubject] = useState<number | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'present' | 'absent'>('all');
  const [filteredRecords, setFilteredRecords] = useState<typeof attendanceRecords>([]);
  const [dateRange, setDateRange] = useState<{
    startDate: string;
    endDate: string;
  }>({
    startDate: '',
    endDate: ''
  });
  
  useEffect(() => {
    if (!currentUser) return;
    
    let filtered = attendanceRecords.filter(
      record => record.studentId === currentUser.id
    );
    
    // Apply subject filter
    if (filterSubject !== null) {
      filtered = filtered.filter(record => record.subjectId === filterSubject);
    }
    
    // Apply status filter
    if (filterStatus === 'present') {
      filtered = filtered.filter(record => record.present);
    } else if (filterStatus === 'absent') {
      filtered = filtered.filter(record => !record.present);
    }
    
    // Apply date range filter
    if (dateRange.startDate) {
      filtered = filtered.filter(record => record.date >= dateRange.startDate);
    }
    
    if (dateRange.endDate) {
      filtered = filtered.filter(record => record.date <= dateRange.endDate);
    }
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(record => {
        const subject = subjects.find(s => s.id === record.subjectId);
        return subject?.name.toLowerCase().includes(term) || 
               subject?.code.toLowerCase().includes(term) ||
               record.date.includes(term);
      });
    }
    
    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    setFilteredRecords(filtered);
  }, [currentUser, filterSubject, filterStatus, searchTerm, dateRange]);
  
  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  // Get subject name
  const getSubjectName = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };
  
  // Reset all filters
  const resetFilters = () => {
    setSearchTerm('');
    setFilterSubject(null);
    setFilterStatus('all');
    setDateRange({ startDate: '', endDate: '' });
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  // Calculate attendance statistics
  const calculateStats = () => {
    const totalRecords = filteredRecords.length;
    const presentRecords = filteredRecords.filter(r => r.present).length;
    const absentRecords = totalRecords - presentRecords;
    
    return {
      total: totalRecords,
      present: presentRecords,
      absent: absentRecords,
      percentage: totalRecords > 0 ? (presentRecords / totalRecords) * 100 : 0
    };
  };
  
  const stats = calculateStats();
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Attendance Records</h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700 mb-6">
        <div className="flex flex-col lg:flex-row lg:items-end space-y-4 lg:space-y-0 lg:space-x-4 mb-6">
          <div className="flex-1">
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Search
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="search"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                placeholder="Search by subject..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Subject
            </label>
            <select
              id="subject"
              className="block w-full py-2 pl-3 pr-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              value={filterSubject === null ? '' : filterSubject}
              onChange={(e) => setFilterSubject(e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">All Subjects</option>
              {subjects.map(subject => (
                <option key={subject.id} value={subject.id}>
                  {subject.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Status
            </label>
            <select
              id="status"
              className="block w-full py-2 pl-3 pr-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'all' | 'present' | 'absent')}
            >
              <option value="all">All</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Start Date
            </label>
            <input
              type="date"
              id="startDate"
              className="block w-full py-2 px-3 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              value={dateRange.startDate}
              onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              End Date
            </label>
            <input
              type="date"
              id="endDate"
              className="block w-full py-2 px-3 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              value={dateRange.endDate}
              onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
            />
          </div>
          
          <div>
            <button
              onClick={resetFilters}
              className="w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 focus:outline-none"
            >
              Reset
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg text-center">
            <h3 className="text-sm font-medium text-blue-700 dark:text-blue-400 mb-1">Total Records</h3>
            <p className="text-3xl font-bold text-blue-800 dark:text-blue-300">{stats.total}</p>
          </div>
          
          <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg text-center">
            <h3 className="text-sm font-medium text-green-700 dark:text-green-400 mb-1">Present</h3>
            <p className="text-3xl font-bold text-green-800 dark:text-green-300">{stats.present}</p>
          </div>
          
          <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg text-center">
            <h3 className="text-sm font-medium text-red-700 dark:text-red-400 mb-1">Absent</h3>
            <p className="text-3xl font-bold text-red-800 dark:text-red-300">{stats.absent}</p>
          </div>
          
          <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg text-center">
            <h3 className="text-sm font-medium text-purple-700 dark:text-purple-400 mb-1">Attendance %</h3>
            <p className="text-3xl font-bold text-purple-800 dark:text-purple-300">{Math.round(stats.percentage)}%</p>
          </div>
        </div>
        
        {filteredRecords.length > 0 ? (
          <div className="overflow-hidden border border-gray-200 dark:border-gray-700 rounded-lg">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Subject
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {filteredRecords.map(record => (
                  <tr key={record.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900 dark:text-white">
                          {formatDate(record.date)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {getSubjectName(record.subjectId)}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {subjects.find(s => s.id === record.subjectId)?.code}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.present ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                          <Check className="h-3 w-3 mr-1" /> Present
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200">
                          <X className="h-3 w-3 mr-1" /> Absent
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <Filter className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No matching records found</h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your search or filter criteria
            </p>
            <button
              onClick={resetFilters}
              className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecordsPage;