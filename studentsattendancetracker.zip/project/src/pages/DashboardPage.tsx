import React from 'react';
import AttendanceOverview from '../components/dashboard/AttendanceOverview';
import SubjectSummary from '../components/dashboard/SubjectSummary';
import PredictionWidget from '../components/dashboard/PredictionWidget';
import RecentAttendance from '../components/dashboard/RecentAttendance';

const DashboardPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <AttendanceOverview />
        <PredictionWidget />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SubjectSummary />
        <RecentAttendance />
      </div>
    </div>
  );
};

export default DashboardPage;