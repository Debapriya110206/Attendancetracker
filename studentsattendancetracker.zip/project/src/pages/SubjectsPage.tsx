import React from 'react';
import SubjectsGrid from '../components/subjects/SubjectsGrid';

const SubjectsPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Subjects</h1>
      <SubjectsGrid />
    </div>
  );
};

export default SubjectsPage;