import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import SubjectDetail from '../components/subjects/SubjectDetail';

const SubjectDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  
  // Handle invalid ID
  if (!id || isNaN(Number(id))) {
    return <Navigate to="/subjects" />;
  }
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Subject Details</h1>
      <SubjectDetail subjectId={Number(id)} />
    </div>
  );
};

export default SubjectDetailPage;