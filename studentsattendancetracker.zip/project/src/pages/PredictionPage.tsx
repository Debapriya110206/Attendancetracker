import React from 'react';
import PredictionChart from '../components/prediction/PredictionChart';
import SubjectPrediction from '../components/prediction/SubjectPrediction';

const PredictionPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Attendance Prediction</h1>
      
      <div className="space-y-6">
        <PredictionChart />
        <SubjectPrediction />
      </div>
    </div>
  );
};

export default PredictionPage;