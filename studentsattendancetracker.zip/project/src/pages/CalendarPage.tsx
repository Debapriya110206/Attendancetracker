import React from 'react';
import AttendanceCalendar from '../components/calendar/AttendanceCalendar';

const CalendarPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Calendar</h1>
      <AttendanceCalendar />
    </div>
  );
};

export default CalendarPage;